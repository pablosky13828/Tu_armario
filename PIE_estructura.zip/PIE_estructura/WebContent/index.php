<!DOCTYPE html>
<html>
<head>
	<title>Index example php. Change for the pages of each project</title>
</head>
<body>
Example
</body>
</html>