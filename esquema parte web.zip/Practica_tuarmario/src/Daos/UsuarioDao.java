package Daos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Domains.Usuario;

public class UsuarioDao {
	public static List<Usuario> selectUsuariosBDStatic() throws ClassNotFoundException, SQLException{
		Connection connection = ManageDB.connectToDB();
		Statement st = connection.createStatement();
		
		ResultSet datos = st.executeQuery("SELECT * FROM Usuarios");
		
		List<Usuario> listaUsuarios = new ArrayList<>();
		while(datos.next()) {
			int id = datos.getInt("id");
			String email = datos.getString("Email");
			String contrase�a = datos.getString("Contrase�a");
			
		Usuario datosUsuario = new Usuario(id,email,contrase�a);
		listaUsuarios.add(datosUsuario);
		
		}
		ManageDB.closeConnection(connection);
		return listaUsuarios;
	}
	
	public static void borrarUsuario(int id) throws ClassNotFoundException, SQLException{
		
		Connection connection = ManageDB.connectToDB();
		Statement st = connection.createStatement();
		
		st.executeUpdate("DELETE FROM usuarios WHERE id =" + id);
		
		ManageDB.closeConnection(connection);
		st.close();
	}

	public static void anadirUsuario(String email, String contrase�a) throws ClassNotFoundException, SQLException{
		
		Connection connection = ManageDB.connectToDB();
		Statement st = connection.createStatement();
		
		st.executeUpdate("INSERT INTO usuarios (email,contrase�a)" + "VALUES ('" + email + "' , '"
				+ contrase�a+"')");
		
		ManageDB.closeConnection(connection);
		st.close();
	}
	public static void editarUsuario(int id, String email, String contrase�a) throws ClassNotFoundException, SQLException {
		
		Connection connection = ManageDB.connectToDB();
		Statement st = connection.createStatement();

		st.executeUpdate("UPDATE usuarios SET email ='" + email + "' WHERE id =" + id);
		st.executeUpdate("UPDATE usuarios SET contrase�a ='" + contrase�a + "' WHERE id =" + id);
	

		ManageDB.closeConnection(connection);
		st.close();
	}
}
