package Daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ManageDB {
	public static Connection connectToDB() throws ClassNotFoundException, SQLException{
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tuarmario","root","1234");
		return connection;
	}
	public static void closeConnection(Connection connection) throws SQLException{
		connection.close();
		
	}
}
