package Services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import Daos.UsuarioDao;
import Domains.Usuario;
import Domains.Usuario;
import Daos.UsuarioDao;


public class UsuarioService {
	UsuarioDao usuariodao;
	
	public static List<Usuario> listaUsuarioStatic() throws ClassNotFoundException, SQLException{
		boolean aniadido = false;
		//Logica
		List<Usuario> listaUsuarios = new ArrayList();
		//Llamada al DAO 
		listaUsuarios = UsuarioDao.selectUsuariosBDStatic();
		return listaUsuarios;
 	}
	public static void borrarUsuarioStatic(int id) throws ClassNotFoundException, SQLException{
		UsuarioDao.borrarUsuario(id);
	}
	public static void anadirUsuarioStatic(String email, String contrase�a) throws ClassNotFoundException, SQLException {

		UsuarioDao.anadirUsuario(email,contrase�a);
	}

	public static void editarUsuarioStatic(int id,String email, String contrase�a) throws ClassNotFoundException, SQLException {

		UsuarioDao.editarUsuario(id,email, contrase�a);
	}
}
	

