package Domains;

public class Usuario {
	private int id;
	private String email;
	private String contrase�a;

	public Usuario(int id, String email, String contrase�a) {
		super();
		this.id=id;
		this.email=email;
		this.contrase�a=contrase�a;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String email() {
		return email;
	}
	public void setemail(String email) {
		this.email = email;
	}
	public String contrase�a() {
		return contrase�a;
	}
	public void setcontrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", email=" + email + ", contrase�a=" + contrase�a + "]";
	}



	

}